"""ייבוא מטופלים מקובץ Excel (כל הגיליונות). שימוש: python import_patients.py patients.xlsx
עמודות לפי סדר: ת.זהות, שם משפחה, שם פרטי, תאריך לידה, טלפון, עיר, קופ"ח. ת"ז קצרות מ-9 ספרות מושלמות באפסים מובילים."""
import sys
from openpyxl import load_workbook
import app

def t(v):
    if v is None: return ''
    if hasattr(v,'strftime'): return v.strftime('%Y-%m-%d')
    if isinstance(v,float) and v.is_integer(): v=int(v)
    return str(v).strip()

app.init(); c=app.db()
for ws in load_workbook(sys.argv[1],read_only=True).worksheets:
    rows=ws.iter_rows(values_only=True); next(rows,None); new=dup=bad=0
    for r in rows:
        r=list(r)+['']*7
        ni=t(r[0])
        name=(t(r[2])+' '+t(r[1])).strip()
        if not ni.isdigit() or not name: bad+=1; continue
        bd=t(r[3]); bd='' if bd.startswith('0000') else bd
        if c.execute('insert or ignore into patients(national_id,name,phone,hmo,address,birth_date) values(?,?,?,?,?,?)',(ni.zfill(9),name,t(r[4]),t(r[6]),t(r[5]),bd)).rowcount: new+=1
        else: dup+=1
    print(f'{ws.title}: חדשים {new}, כפולים {dup}, לא תקינים {bad}')
c.commit(); c.close()
