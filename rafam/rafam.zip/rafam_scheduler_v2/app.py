from flask import Flask, abort, render_template, request, redirect, url_for, session, jsonify
import sqlite3, os, secrets, csv, io
from markupsafe import Markup
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta

app=Flask(__name__)
app.secret_key=os.environ.get('SECRET_KEY') or secrets.token_hex(32)  # בלי SECRET_KEY: מפתח אקראי, והחיבורים מתאפסים בכל הפעלה
app.config.update(SESSION_COOKIE_HTTPONLY=True,SESSION_COOKIE_SAMESITE='Lax',SESSION_COOKIE_SECURE=os.environ.get('COOKIE_SECURE')=='1')
DB='scheduler.db'
CLINICS=['יהודה הנשיא','נתיבות המשפט']

def db():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init():
 c=db(); c.executescript('''
 CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT, role TEXT);
 CREATE TABLE IF NOT EXISTS doctors(id INTEGER PRIMARY KEY, name TEXT, clinic TEXT, slot_minutes INTEGER NOT NULL DEFAULT 10, active INTEGER DEFAULT 1);
 CREATE TABLE IF NOT EXISTS shifts(id INTEGER PRIMARY KEY, doctor_id INTEGER, weekday INTEGER, start TEXT, end TEXT, active INTEGER DEFAULT 1);
 CREATE TABLE IF NOT EXISTS patients(id INTEGER PRIMARY KEY, national_id TEXT UNIQUE, name TEXT, phone TEXT, hmo TEXT, address TEXT);
 CREATE TABLE IF NOT EXISTS appointments(id INTEGER PRIMARY KEY, patient_id INTEGER, doctor_id INTEGER, clinic TEXT, date TEXT, start TEXT, end TEXT, status TEXT DEFAULT 'booked', created_at TEXT);
 CREATE UNIQUE INDEX IF NOT EXISTS ux_appt ON appointments(doctor_id,date,start) WHERE status='booked';
 CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, username TEXT, action TEXT, created_at TEXT);
 ''')
 try: c.execute('alter table patients add column birth_date text')
 except sqlite3.OperationalError: pass
 if not c.execute('select 1 from users limit 1').fetchone():
  pw=os.environ.get('ADMIN_PASSWORD') or secrets.token_urlsafe(12)
  c.execute('insert into users(username,password,role) values(?,?,?)',('admin',generate_password_hash(pw),'admin'))
  print(f'*** נוצר משתמש admin. סיסמה ראשונית: {pw}  (שמור אותה והחלף) ***')
 # Only the doctors already present in the supplied demo; hours are not treated as authoritative final schedule.
 for clinic,names in {'יהודה הנשיא':['קורד','פקטרוביץ','שויער','סולומון','שלג','אלגרדט','אבו סנינה'],'נתיבות המשפט':['שויער','סולומון','שלג','אבו סנינה','קורד','פקטרוביץ']}.items():
  for n in names:
   c.execute('insert into doctors(name,clinic) select ?,? where not exists(select 1 from doctors where name=? and clinic=?)',(n,clinic,n,clinic))
 c.commit(); c.close()

def slots(start,end,minutes):
 out=[]; t=datetime.strptime(start,'%H:%M'); e=datetime.strptime(end,'%H:%M')
 while t+timedelta(minutes=minutes)<=e:
  out.append((t.strftime('%H:%M'),(t+timedelta(minutes=minutes)).strftime('%H:%M'))); t+=timedelta(minutes=minutes)
 return out

def admin(): return session.get('role')=='admin'

@app.context_processor
def inject_csrf():
 def csrf_token():
  if 'csrf' not in session: session['csrf']=secrets.token_hex(16)
  return session['csrf']
 return dict(csrf_token=csrf_token,csrf_input=lambda:Markup(f"<input type='hidden' name='csrf_token' value='{csrf_token()}'>"))

@app.before_request
def check_csrf():
 if request.method=='POST':
  t=session.get('csrf','')
  if not t or not secrets.compare_digest(t,request.form.get('csrf_token','')): abort(400)

@app.route('/',methods=['GET','POST'])
def login():
 if request.method=='POST':
  c=db(); u=c.execute('select * from users where username=?',(request.form['username'],)).fetchone(); c.close()
  if u and check_password_hash(u['password'],request.form['password']): session.clear(); session.update(user=u['username'],role=u['role']); return redirect(url_for('dashboard'))
  return render_template('login.html',error='פרטי הכניסה שגויים')
 return render_template('login.html')
@app.route('/logout')
def logout(): session.clear(); return redirect('/')
@app.route('/dashboard')
def dashboard():
 if 'user' not in session:return redirect('/')
 c=db(); doctors=c.execute('select * from doctors where active=1 order by clinic,name').fetchall(); c.close()
 return render_template('dashboard.html',doctors=doctors,clinics=CLINICS,admin=admin())
@app.post('/admin/doctor/<int:doctor_id>/duration')
def duration(doctor_id):
 if not admin(): return jsonify(ok=False,error='אין הרשאה'),403
 try: val=int(request.form['slot_minutes'])
 except (KeyError,ValueError): return jsonify(ok=False,error='משך לא תקין'),400
 if val not in (10,15,20,30): return jsonify(ok=False,error='משך לא תקין'),400
 c=db(); c.execute('update doctors set slot_minutes=? where id=?',(val,doctor_id)); c.execute('insert into audit(username,action,created_at) values(?,?,?)',(session['user'],f'שינוי משך תור לרופא {doctor_id}: {val} דקות',datetime.now().isoformat(timespec='seconds'))); c.commit(); c.close(); return redirect(url_for('dashboard'))
@app.get('/api/slots')
def api_slots():
 if 'user' not in session:return jsonify(error='login required'),401
 clinic=request.args.get('clinic'); doctor_id=request.args.get('doctor_id'); date=request.args.get('date'); shift_start=request.args.get('start','08:00'); shift_end=request.args.get('end','12:00')
 c=db(); d=c.execute('select * from doctors where id=? and clinic=? and active=1',(doctor_id,clinic)).fetchone();
 if not d:return jsonify(slots=[])
 booked={r['start'] for r in c.execute("select start from appointments where doctor_id=? and date=? and status='booked'",(doctor_id,date)).fetchall()}; c.close()
 return jsonify(slot_minutes=d['slot_minutes'],slots=[{'start':s,'end':e,'available':s not in booked} for s,e in slots(shift_start,shift_end,d['slot_minutes'])])

def nid(v):
 v=v.strip()
 return v.zfill(9) if v.isdigit() and len(v)<9 else v
def logged(): return 'user' in session
def page(view,**k): return render_template('page.html',view=view,admin=admin(),**k)
def log(c,act): c.execute('insert into audit(username,action,created_at) values(?,?,?)',(session['user'],act,datetime.now().isoformat(timespec='seconds')))
def pdate(v):
 try: return datetime.strptime(v,'%Y-%m-%d').strftime('%Y-%m-%d')
 except (TypeError,ValueError): return datetime.now().strftime('%Y-%m-%d')

def day_slots(c,d,date):
 wd=(datetime.strptime(date,'%Y-%m-%d').weekday()+1)%7  # ראשון=0
 booked={r['start'] for r in c.execute("select start from appointments where doctor_id=? and date=? and status='booked'",(d['id'],date))}
 out=[]
 for sh in c.execute('select * from shifts where doctor_id=? and weekday=? and active=1 order by start',(d['id'],wd)).fetchall():
  out+=[{'start':a,'end':b,'free':a not in booked} for a,b in slots(sh['start'],sh['end'],d['slot_minutes'])]
 return out

@app.route('/patients',methods=['GET','POST'])
def patients():
 if not logged(): return redirect('/')
 c=db(); msg=''
 if request.method=='POST':
  f=request.form; ni=nid(f['national_id'])
  if not ni.isdigit() or not f['name'].strip(): msg='ת"ז (ספרות בלבד) ושם הם שדות חובה'
  else:
   try: c.execute('insert into patients(national_id,name,phone,hmo,address) values(?,?,?,?,?)',(ni,f['name'].strip(),f.get('phone','').strip(),f.get('hmo','').strip(),f.get('address','').strip())); c.commit(); msg='המטופל נוסף'
   except sqlite3.IntegrityError: msg='ת"ז כבר קיימת'
 q=request.args.get('q','').strip()
 rows=c.execute('select * from patients where national_id like ? or name like ? or phone like ? order by name limit 50',(f'%{q}%',)*3).fetchall() if q else []
 c.close(); return page('patients',rows=rows,q=q,msg=msg)

@app.post('/patients/import')
def import_patients():
 if not admin(): abort(403)
 f=request.files.get('file'); n=0
 if f:
  c=db()
  for r in csv.DictReader(io.StringIO(f.read().decode('utf-8-sig'))):
   nid=(r.get('national_id') or '').strip()
   if nid.isdigit() and (r.get('name') or '').strip():
    n+=c.execute('insert or ignore into patients(national_id,name,phone,hmo,address) values(?,?,?,?,?)',(nid,r['name'].strip(),r.get('phone') or '',r.get('hmo') or '',r.get('address') or '')).rowcount
  log(c,f'ייבוא מטופלים: {n}'); c.commit(); c.close()
 return page('patients',rows=[],q='',msg=f'יובאו {n} מטופלים חדשים')

@app.route('/book',methods=['GET','POST'])
def book():
 if not logged(): return redirect('/')
 c=db(); msg=''; f=request.values
 docs=c.execute('select * from doctors where active=1 order by clinic,name').fetchall()
 date=pdate(f.get('date')); d=c.execute('select * from doctors where id=? and active=1',(f.get('doctor_id'),)).fetchone() if f.get('doctor_id') else None
 if request.method=='POST' and d:
  p=c.execute('select * from patients where national_id=?',(nid(f.get('national_id','')),)).fetchone()
  if not p: msg='מטופל לא נמצא - הוסף אותו במסך מטופלים'
  elif not any(x['start']==f.get('start') and x['free'] for x in day_slots(c,d,date)): msg='הסלוט כבר לא פנוי'
  else:
   st=f['start']; en=next(x['end'] for x in day_slots(c,d,date) if x['start']==st)
   try: c.execute('insert into appointments(patient_id,doctor_id,clinic,date,start,end,created_at) values(?,?,?,?,?,?,?)',(p['id'],d['id'],d['clinic'],date,st,en,datetime.now().isoformat(timespec='seconds'))); log(c,f'זימון תור: {p["name"]} אצל {d["name"]} {date} {st}'); c.commit(); msg=f'נקבע תור ל{p["name"]} ב-{date} בשעה {st}'
   except sqlite3.IntegrityError: msg='הסלוט נתפס זה עתה'
 sl=day_slots(c,d,date) if d else []; c.close()
 return page('book',docs=docs,d=d,date=date,sl=sl,msg=msg)

@app.route('/appointments',methods=['GET','POST'])
def appointments():
 if not logged(): return redirect('/')
 c=db(); msg=''
 if request.method=='POST':
  c.execute("update appointments set status='cancelled' where id=? and status='booked'",(request.form['id'],)); log(c,f'ביטול תור {request.form["id"]}'); c.commit(); msg='התור בוטל'
 date=pdate(request.args.get('date'))
 rows=c.execute("select a.*,p.name pname,p.national_id,p.phone,d.name dname from appointments a join patients p on p.id=a.patient_id join doctors d on d.id=a.doctor_id where a.date=? and a.status='booked' order by a.clinic,d.name,a.start",(date,)).fetchall(); c.close()
 return page('appointments',rows=rows,date=date,msg=msg)

@app.route('/admin/shifts',methods=['GET','POST'])
def shifts():
 if not admin(): abort(403)
 c=db(); msg=''; f=request.form
 if request.method=='POST':
  try:
   if f.get('delete'): c.execute('delete from shifts where id=?',(f['delete'],)); log(c,f'מחיקת משמרת {f["delete"]}')
   else:
    a=datetime.strptime(f['start'],'%H:%M'); b=datetime.strptime(f['end'],'%H:%M')
    if b<=a or int(f['weekday']) not in range(7): raise ValueError
    c.execute('insert into shifts(doctor_id,weekday,start,end) values(?,?,?,?)',(f['doctor_id'],int(f['weekday']),f['start'],f['end'])); log(c,f'הוספת משמרת לרופא {f["doctor_id"]}')
   c.commit()
  except (ValueError,KeyError): msg='נתוני משמרת לא תקינים'
 rows=c.execute('select s.*,d.name dname,d.clinic from shifts s join doctors d on d.id=s.doctor_id order by d.clinic,d.name,s.weekday,s.start').fetchall()
 docs=c.execute('select * from doctors where active=1 order by clinic,name').fetchall(); c.close()
 return page('shifts',rows=rows,docs=docs,msg=msg)

@app.route('/password',methods=['GET','POST'])
def password():
 if not logged(): return redirect('/')
 msg=''
 if request.method=='POST':
  c=db(); u=c.execute('select * from users where username=?',(session['user'],)).fetchone(); f=request.form
  if not check_password_hash(u['password'],f['old']): msg='הסיסמה הנוכחית שגויה'
  elif len(f['new'])<8 or f['new']!=f['again']: msg='הסיסמה החדשה חייבת להיות לפחות 8 תווים ולהתאים לאימות'
  else: c.execute('update users set password=? where username=?',(generate_password_hash(f['new']),session['user'])); log(c,'החלפת סיסמה'); c.commit(); msg='הסיסמה הוחלפה'
  c.close()
 return page('password',msg=msg)

if __name__=='__main__': init(); app.run(host=os.environ.get('HOST','127.0.0.1'),port=8000)
